# chipotle
The data behind the Upshot's [recent article](http://www.nytimes.com/interactive/2015/02/17/upshot/what-do-people-actually-order-at-chipotle.html) about what people actually order at Chipotle.
